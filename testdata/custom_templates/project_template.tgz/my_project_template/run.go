// Package main runs [[ .project_name ]].
package main
